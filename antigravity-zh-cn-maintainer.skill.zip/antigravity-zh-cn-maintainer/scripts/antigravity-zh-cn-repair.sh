#!/bin/zsh
set -u

APP="/Applications/Antigravity.app"
RESOURCE="$APP/Contents/Resources/app.asar"
INFO_PLIST="$APP/Contents/Info.plist"
PATCH_DIR="$HOME/Library/Application Support/Antigravity/zh-cn-patch"
PATCH_ASAR="$PATCH_DIR/app.asar.zh-cn"
PATCH_INFO="$PATCH_DIR/Info.plist.zh-cn"
HASH_FILE="$PATCH_DIR/app.asar.sha256"
LOG_FILE="$PATCH_DIR/repair.log"

mkdir -p "$PATCH_DIR"

log() {
  printf '[%s] %s\n' "$(/bin/date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

if [[ ! -d "$APP" ]]; then
  log "Antigravity.app not found; skip."
  exit 0
fi

if [[ ! -f "$PATCH_ASAR" || ! -f "$PATCH_INFO" || ! -f "$HASH_FILE" ]]; then
  log "Patch payload missing; skip."
  exit 0
fi

TARGET_HASH="$(/bin/cat "$HASH_FILE" 2>/dev/null | /usr/bin/tr -d '[:space:]')"
CURRENT_HASH=""
if [[ -f "$RESOURCE" ]]; then
  CURRENT_HASH="$(/usr/bin/shasum -a 256 "$RESOURCE" | /usr/bin/awk '{print $1}')"
fi

if [[ "$CURRENT_HASH" == "$TARGET_HASH" ]]; then
  log "Chinese patch already active."
  exit 0
fi

log "Patch mismatch detected. current=${CURRENT_HASH:-missing} target=$TARGET_HASH"

/usr/bin/osascript -e 'tell application "Antigravity" to quit' >/dev/null 2>&1 || true
/bin/sleep 2

/bin/cp "$PATCH_ASAR" "$RESOURCE"
/bin/cp "$PATCH_INFO" "$INFO_PLIST"

if /usr/bin/codesign --force --deep --sign - "$APP" >> "$LOG_FILE" 2>&1; then
  log "Chinese patch restored and app re-signed."
else
  log "codesign failed while restoring Chinese patch."
  exit 1
fi

exit 0
