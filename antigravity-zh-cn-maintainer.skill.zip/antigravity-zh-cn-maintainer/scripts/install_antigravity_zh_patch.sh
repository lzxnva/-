#!/bin/zsh
set -euo pipefail

APP="${APP:-/Applications/Antigravity.app}"
PATCH_DIR="${PATCH_DIR:-$HOME/Library/Application Support/Antigravity/zh-cn-patch}"
LAUNCH_AGENT="$HOME/Library/LaunchAgents/com.lizeju.antigravity.zh-cn-repair.plist"

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
DEFAULT_PAYLOAD_DIR="$SOURCE_DIR/../assets/current-patch"
ASAR="${1:-$DEFAULT_PAYLOAD_DIR/app.asar.zh-cn}"
INFO="${2:-$DEFAULT_PAYLOAD_DIR/Info.plist.zh-cn}"
HASH_FILE="${3:-$DEFAULT_PAYLOAD_DIR/app.asar.sha256}"
REPAIR_SCRIPT="$SOURCE_DIR/antigravity-zh-cn-repair.sh"
PLIST="$SOURCE_DIR/com.lizeju.antigravity.zh-cn-repair.plist"

if [[ ! -d "$APP" ]]; then
  echo "找不到 $APP" >&2
  exit 1
fi

for file in "$ASAR" "$INFO" "$HASH_FILE" "$REPAIR_SCRIPT" "$PLIST"; do
  if [[ ! -f "$file" ]]; then
    echo "缺少文件：$file" >&2
    exit 1
  fi
done

mkdir -p "$PATCH_DIR" "$HOME/Library/LaunchAgents"

osascript -e 'tell application "Antigravity" to quit' >/dev/null 2>&1 || true
sleep 2

cp "$ASAR" "$APP/Contents/Resources/app.asar"
cp "$INFO" "$APP/Contents/Info.plist"
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"

cp "$ASAR" "$PATCH_DIR/app.asar.zh-cn"
cp "$INFO" "$PATCH_DIR/Info.plist.zh-cn"
cp "$HASH_FILE" "$PATCH_DIR/app.asar.sha256"
cp "$REPAIR_SCRIPT" "$PATCH_DIR/antigravity-zh-cn-repair.sh"
chmod +x "$PATCH_DIR/antigravity-zh-cn-repair.sh"
cp "$PLIST" "$LAUNCH_AGENT"
/usr/libexec/PlistBuddy -c "Delete :ProgramArguments" "$LAUNCH_AGENT"
/usr/libexec/PlistBuddy -c "Add :ProgramArguments array" "$LAUNCH_AGENT"
/usr/libexec/PlistBuddy -c "Add :ProgramArguments:0 string $PATCH_DIR/antigravity-zh-cn-repair.sh" "$LAUNCH_AGENT"
/usr/libexec/PlistBuddy -c "Set :StandardOutPath $PATCH_DIR/launchd.out.log" "$LAUNCH_AGENT"
/usr/libexec/PlistBuddy -c "Set :StandardErrorPath $PATCH_DIR/launchd.err.log" "$LAUNCH_AGENT"
plutil -lint "$LAUNCH_AGENT"

UID_VALUE="$(id -u)"
launchctl bootout "gui/$UID_VALUE" "$LAUNCH_AGENT" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$UID_VALUE" "$LAUNCH_AGENT"
launchctl print "gui/$UID_VALUE/com.lizeju.antigravity.zh-cn-repair"

echo "Antigravity 汉化补丁已安装，并已加载开机自修复 LaunchAgent。"
