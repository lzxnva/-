# Antigravity 汉化维护参考

## 当前已验证方案

Antigravity 是 Electron 应用，主要界面逻辑打包在：

```text
/Applications/Antigravity.app/Contents/Resources/app.asar
```

macOS 版本还会在 `Info.plist` 里保存 asar 完整性哈希。只替换 `app.asar` 不更新该哈希会导致启动异常或资源校验失败。

## 关键修改点

- `dist/preload.js`：运行时 DOM 汉化层，覆盖主界面、设置页、动态弹窗、Shadow DOM、placeholder、aria-label、title。
- `dist/preload.js`：同时要对左侧项目名、路径提示和错误框里的百分号编码文本做保守 URL 解码，例如 `%E5%8A%9E%E5%85%AC` 应显示为“办公”。
- `dist/menu.js`：macOS 菜单栏汉化。
- `dist/loadingOverlay.js`：启动加载页汉化。
- `dist/ideInstall/wizardHtml.js`：Antigravity 本体内的 IDE 安装向导汉化。
- `dist/tray.js`：菜单栏/托盘代理状态汉化。
- `dist/updater.js`：禁用自动更新检查、下载和安装。
- `dist/ipcHandlers.js`：拦截更新安装 IPC。

## 验证重点

必须验证这些页面：

- 启动页：应显示“正在加载 Antigravity”。
- 菜单栏：文件、编辑、显示、窗口、帮助。
- 主界面：新建对话、对话历史、计划任务、项目、设置、输入框。
- 左侧项目/文件夹名：中文目录不能显示成 `%E5%...` 这类百分号编码。
- 设置页：账户、权限、外观、模型、自定义、浏览器、应用、快捷键、提供反馈。
- 自动修复：LaunchAgent `com.lizeju.antigravity.zh-cn-repair` 已加载，repair.log 应出现 `Chinese patch already active.`。

## 恢复策略

如果用户需要恢复官方原版：

1. 退出 Antigravity。
2. 把备份的 `app.asar` 和 `Info.plist` 复制回 app 包。
3. 重新执行 `codesign --force --deep --sign - /Applications/Antigravity.app`。
4. 如不再需要自修复，卸载 LaunchAgent：

```bash
launchctl bootout gui/$(id -u) "$HOME/Library/LaunchAgents/com.lizeju.antigravity.zh-cn-repair.plist"
```

## 维护建议

不要依赖系统语言设置完成汉化。Antigravity 本体没有完整中文资源包时，系统语言只能覆盖少量原生 UI。当前方案通过资源包补丁和运行时 DOM 翻译实现更高覆盖率。
