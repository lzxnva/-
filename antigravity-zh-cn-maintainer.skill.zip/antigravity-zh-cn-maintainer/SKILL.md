---
name: antigravity-zh-cn-maintainer
description: Maintain the Google Antigravity macOS app Chinese localization patch. Use when the user asks to localize Antigravity, re-apply the zh-CN patch after an app update, disable Antigravity auto-updates, verify the patched app signature and asar integrity, or install/check the LaunchAgent that restores the localized app after login or reboot. This skill is for /Applications/Antigravity.app only, not Antigravity IDE.
---

# Antigravity 汉化维护

## 核心边界

只处理 `/Applications/Antigravity.app` 和 `~/Library/Application Support/Antigravity`。

不要修改 `Antigravity IDE`、`~/Library/Application Support/Antigravity IDE` 或 `com.google.antigravity-ide`，除非用户明确改口。

## 推荐流程

1. 先确认目标 app：
   - `/Applications/Antigravity.app`
   - bundle id: `com.google.antigravity`
2. 备份当前文件：
   - `Contents/Resources/app.asar`
   - `Contents/Info.plist`
3. 解包 `app.asar` 到工作目录，修改 `dist/` 下的主进程、preload、菜单、更新器和安装向导文本。
4. 对 `dist/preload.js` 维护运行时汉化表：
   - `zhText` 处理完整文本。
   - `zhPartialText` 处理带数字、模型名、链接组合的文本。
   - `zhInlineText` 处理被 React/Markdown 拆成多个 DOM 节点的英文片段。
   - 先对可见文本和属性里的 `%E5%8A%9E%E5%85%AC` 这类百分号编码片段做保守 URL 解码，再进入中文替换。
   - MutationObserver 和 `Element.prototype.attachShadow` 用于覆盖动态 DOM 和 Shadow DOM。
5. 禁用自动更新：
   - 在 `dist/updater.js` 中让 `initAutoUpdater`、`checkForUpdates`、`quitAndInstall` 直接返回。
   - 在 `dist/ipcHandlers.js` 中拦截 `updater:quit-and-install`。
6. 重新打包并写入完整性哈希：
   - `asar pack <workdir> app.asar.zh-cn`
   - `shasum -a 256 app.asar.zh-cn`
   - 用 `/usr/libexec/PlistBuddy` 更新 `Info.plist` 的 `ElectronAsarIntegrity:Resources:app.asar:hash`。
7. 替换 app 包内文件并签名：
   - `cp app.asar.zh-cn /Applications/Antigravity.app/Contents/Resources/app.asar`
   - `cp Info.plist.zh-cn /Applications/Antigravity.app/Contents/Info.plist`
   - `codesign --force --deep --sign - /Applications/Antigravity.app`
8. 验证：
   - `node --check` 检查改过的 JS。
   - `codesign --verify --deep --strict --verbose=2 /Applications/Antigravity.app`
   - 用 Computer Use 打开 Antigravity，检查启动页、菜单、主界面、设置页。
   - 左侧项目/文件夹名如果最初是 `%E5%...`，应显示为正常中文而不是百分号编码。

## 开机自修复

使用 `scripts/antigravity-zh-cn-repair.sh` 作为 LaunchAgent 程序。它会比较当前 `app.asar` 哈希和保存的汉化包哈希；不一致时自动恢复汉化包、恢复匹配 `Info.plist`、重新签名。

推荐安装位置：

```text
~/Library/Application Support/Antigravity/zh-cn-patch/
~/Library/LaunchAgents/com.lizeju.antigravity.zh-cn-repair.plist
```

LaunchAgent 建议：

```text
RunAtLoad = true
StartInterval = 1800
```

这样登录时会运行一次，之后每 30 分钟检查一次。

## 当前补丁资产

如果 `assets/current-patch/` 存在，优先使用里面的当前汉化补丁：

```text
assets/current-patch/app.asar.zh-cn
assets/current-patch/Info.plist.zh-cn
assets/current-patch/app.asar.sha256
```

这些文件是版本相关的。若 Antigravity 官方版本升级，应重新解包新版本并生成新的资产，不要盲目把旧 asar 用在新版 app 上。

## 常用命令

```bash
node --check antigravity-asar-work/dist/preload.js
node --check antigravity-asar-work/dist/updater.js
node --check antigravity-asar-work/dist/ipcHandlers.js
asar pack antigravity-asar-work antigravity-app.zh-cn.asar
shasum -a 256 antigravity-app.zh-cn.asar
codesign --verify --deep --strict --verbose=2 /Applications/Antigravity.app
launchctl print gui/$(id -u)/com.lizeju.antigravity.zh-cn-repair
tail -n 20 "$HOME/Library/Application Support/Antigravity/zh-cn-patch/repair.log"
```

## 注意事项

修改 Electron app 包会破坏 Google 原签名，需要本机 ad-hoc 签名。

官方更新被禁用是为了保护汉化补丁。用户以后若要升级 Antigravity，应先备份当前汉化包，再升级，再重新汉化新版本。

如果启动失败，先恢复备份的 `app.asar` 和 `Info.plist`，再重新签名。
